<template>
  <div>
      <h3 class="title">titulo: {{title}}</h3>
      <p>
        <strong>John Smith</strong><small>@johnsmith</small><small>31m</small>
        <br>
            Lorem ipsun dolor sit amet, Lorem ipsun dolor sit amet,Lorem ipsun dolor sit amet,Lorem ipsun dolor sit amet,Lorem ipsun dolor sit amet,
      </p>
  </div>
</template>

<script>
export default {
  data () {
    return {
      title: 'Título del componente 2'
    };
  }
}
</script>
<style>
div {
  border: 1px balck solid;
}
</style>
