<template>
  <div id="app">
    <h1 class="title">{{title}}</h1>
    <app-comment-block :title="title"></app-comment-block>
    <app-info></app-info>


  </div>
</template>

<script>
import AppCommentBlock from './ChildOne.vue';
import AppInfo from './ChildTwo.vue';


export default {
  data () {
    return {
      title: 'Título del padre'
    };
  },
  components: {
    AppCommentBlock,
    AppInfo
  }
}
</script>

<style scoped>
#parent {
  width: 80%;
  margin: 2em auto;
  background: #8655b7;
  padding: 3em;
}

.title {
  color: black;
}

h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}
</style>
