<template>
  <div class="midiv">
      <img src="http://bulma.io/images/placeholders/128x128.png" alt="Image">
      <h3 class="title">titulo: {{title}}</h3>
      <p>
        <strong>John Smith</strong><small>@johnsmith</small><small>31m</small>
        <br>
            Lorem ipsun dolor sit amet, Lorem ipsun dolor sit amet,Lorem ipsun dolor sit amet,Lorem ipsun dolor sit amet,Lorem ipsun dolor sit amet,
      </p>
  </div>
</template>

<script>
export default {
  props: ['title'],
}
</script>
<style>
.midiv {
  border: 1px black solid;
}

</style>
