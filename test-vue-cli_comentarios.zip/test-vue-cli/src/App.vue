<template>
  <div id="app">
    <article>
      <h1 class="title">Las tarjetas de embarque serán historia </h1>
      <p>Se trata de una secuencia que los viajeros conocen bien: tras superar el minucioso control de seguridad, toca una nueva parada
        en la puerta de embarque en la que hay que presentar una vez mas el billete y algún documento identificativo</p>
    </article>
    <app-comment-box></app-comment-box>
  </div>
</template>

<script>
import AppCommentBox from './CommentBox.vue';

export default {
  name:'app',
  components: {
    AppCommentBox,
  }

}
</script>

<style>
#app {
  color: #2c3e50;
  border: 1px solid #ddd;
  padding: 1em;
  width: 80%;
  margin: 5px auto;
}

</style>
