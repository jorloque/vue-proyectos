<template>
  <div class="midiv">
      <h3 class="title">titulo: {{title}}</h3>
      <div class="tile notification is-danger">
        <p class="subtitle">¿Qué película estás viendo?</p>
        <div class="content">
          <p>{{watching}}</p>
        </div>
      </div>
      <button class="delete is-small" @click="closeModal"></button>
  </div>
</template>

<script>
import {eventBus} from './main';

export default {
  props: {
    watching :{
      type:String,
      required:true,
    }
  },
  methods: {
    closeModal() {
      this.$emit('closeModal');
    }
  },
  created() {
    eventBus.$on('changeMovie', (movie) => {
      this.watching = movie;
    });
  }
}

</script>


<style>
.midiv {
  border: 1px black solid;
  padding: 5px;
  margin:2px;
}
</style>
