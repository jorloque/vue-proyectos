<template>
  <div class="app-CommentBox">
    <app-comment-form @newComment="addComment"></app-comment-form>
      <div class="app-CommentBox_List">
        <transition-group name="fade">
                <app-single-comment
                  v-for="(comment, index) in comments"
                  :comment="comment"
                  :index="index"
                  :key="index"
                  @Remove="removeComment"
                >
                </app-single-comment>
        </transition-group>
      </div>
  </div>
</template>

<script>
import AppSingleComment from './SingleComment.vue';
import AppCommentForm from './CommentForm.vue';


export default {
  name: 'app-comment-box',
  data() {
    return {
      comments : [
        { user:'Alejandro Rivas', userReference:'@alri', message:'Me gusta la idea'},
        { user:'Manuel Perez', userReference:'@mape', message:'Lo apoyo, es una estupenda idea'},
      ]
    }
  },
  components:{
    AppSingleComment,
    AppCommentForm
  },
  methods: {
    removeComment(index) {
      this.comments.splice(index, 1);
    },
    addComment(user, userReference, message){
      this.comments.push ({
        user,
        userReference,
        message,
      });
    }
  }
}
</script>

<style>
.fade-enter-active,
.fade-leave-active {
  transition: opacity .5s;
}
.fade-enter,
.fade-leave-to {
  opacity: 0;
}
</style>
